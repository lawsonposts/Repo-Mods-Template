﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;

[BepInPlugin("lawson.xmods.guitemplate", "XMODS GUI Template", "1.5.0")]
public class XMODSGUITemplate : BaseUnityPlugin
{
	public static XMODSGUITemplate Instance { get; private set; }

	public bool InfiniteStaminaEnabled => staminaEnabled;
	public bool InfiniteHealthEnabled => healthEnabled;

	private bool menuOpen;
	private bool subMenuOpen;
	private bool showingCatalog;
	private bool showingRpcBrowser;

	private float animation;
	private int selected;
	private int subSelected;

	private float speedMultiplier = 2f;
	private float jumpMultiplier = 1.5f;

	private bool speedEnabled;
	private bool jumpEnabled;
	private bool staminaEnabled;
	private bool flyEnabled;
	private bool upDownEnabled;
	private bool carEnabled;
	private bool healthEnabled;
	private bool monsterESP;
	private bool itemESP;
	private bool playerESP;

	private PlayerController cachedPlayer;

	private float originalMoveSpeed;
	private float originalSprintSpeed;
	private float originalCrouchSpeed;
	private float originalEnergyDrain;
	private float originalJumpValue;

	private FieldInfo jumpField;
	private FieldInfo godModeField;
	private object cachedHealth;

	private bool jumpFieldInitialized;
	private bool jumpWarningLogged;

	private Harmony harmony;

	private readonly string[] categories =
	{
		"Movement",
		"Audio",
		"Visual",
		"Trolling",
		"Overpowered"
	};

	private readonly string[][] mods =
	{
		new[]
		{
			"Speed Multiplier",
			"Jump Multiplier",
			"Infinite Stamina",
			"Fly",
			"Up N Down",
			"Car"
		},
		new[]
		{
			"Empty",
			"Empty"
		},
		new[]
		{
			"MonsterESP",
			"ItemESP",
			"PlayerESP"
		},
		new[]
		{
			"RPC Browser (Read Only)"
		},
		new[]
		{
			"SpawnItems",
			"SpawnMonsters",
			"Infinite Health",
			"Destroy All Monsters",
			"Max Money"
		}
	};

	private readonly List<object> itemCatalog = new List<object>();
	private readonly List<object> monsterCatalog = new List<object>();
	private readonly List<string> rpcCatalog = new List<string>();

	private readonly List<GameObject> espMonsters = new List<GameObject>();
	private readonly List<GameObject> espItems = new List<GameObject>();
	private readonly List<GameObject> espPlayers = new List<GameObject>();

	private readonly HashSet<int> monsterIds = new HashSet<int>();
	private readonly HashSet<int> itemIds = new HashSet<int>();
	private readonly HashSet<int> playerIds = new HashSet<int>();

	private float nextESPRefresh;
	private const float ESPRefreshInterval = 1f;

	private GUIStyle titleStyle;
	private GUIStyle categoryStyle;
	private GUIStyle footerStyle;
	private GUIStyle hintStyle;

	private readonly Color pink = new Color(0.88f, 0.42f, 0.63f);
	private readonly Color white = Color.white;
	private readonly Color mutedWhite = new Color(0.82f, 0.82f, 0.82f);

	private string catalogTitle = "";

	private void Awake()
	{
		Instance = this;
		harmony = new Harmony("lawson.xmods.gui");
		harmony.PatchAll();
	}

	private void Update()
	{
		if (UnityEngine.Input.GetKeyDown(KeyCode.F4))
		{
			menuOpen = !menuOpen;

			if (!menuOpen)
			{
				subMenuOpen = false;
				showingCatalog = false;
				showingRpcBrowser = false;
			}
		}

		animation = Mathf.MoveTowards(
			animation,
			menuOpen ? 1f : 0f,
			Time.unscaledDeltaTime * 5f
		);

		ApplyMods();
		ApplyExtraMovement();
		ApplyHealth();

		if (!menuOpen)
			return;

		if (showingRpcBrowser)
		{
			if (rpcCatalog.Count > 0)
			{
				if (UnityEngine.Input.GetKeyDown(KeyCode.UpArrow))
					subSelected = (subSelected - 1 + rpcCatalog.Count)
						% rpcCatalog.Count;

				if (UnityEngine.Input.GetKeyDown(KeyCode.DownArrow))
					subSelected = (subSelected + 1) % rpcCatalog.Count;
			}

			if (UnityEngine.Input.GetKeyDown(KeyCode.Backspace))
			{
				showingRpcBrowser = false;
				subMenuOpen = true;
				subSelected = 0;
			}

			return;
		}

		if (showingCatalog)
		{
			int count = CurrentCatalog().Count;

			if (count > 0)
			{
				if (UnityEngine.Input.GetKeyDown(KeyCode.UpArrow))
					subSelected = (subSelected - 1 + count) % count;

				if (UnityEngine.Input.GetKeyDown(KeyCode.DownArrow))
					subSelected = (subSelected + 1) % count;

				if (UnityEngine.Input.GetKeyDown(KeyCode.Return))
					SpawnCatalogEntry(subSelected);
			}

			if (UnityEngine.Input.GetKeyDown(KeyCode.Backspace))
			{
				showingCatalog = false;
				subMenuOpen = true;
				subSelected = catalogTitle == "Spawn Monsters" ? 1 : 0;
			}

			return;
		}

		if (subMenuOpen)
		{
			int count = mods[selected].Length;

			if (UnityEngine.Input.GetKeyDown(KeyCode.UpArrow))
				subSelected = (subSelected - 1 + count) % count;

			if (UnityEngine.Input.GetKeyDown(KeyCode.DownArrow))
				subSelected = (subSelected + 1) % count;

			if (UnityEngine.Input.GetKeyDown(KeyCode.Backspace))
				subMenuOpen = false;

			if (UnityEngine.Input.GetKeyDown(KeyCode.Return))
				ToggleSelectedMod();

			if (selected == 0 && (subSelected == 0 || subSelected == 1))
			{
				if (UnityEngine.Input.GetKeyDown(KeyCode.RightArrow))
				{
					if (subSelected == 0)
						speedMultiplier = Mathf.Min(
							5f, speedMultiplier + 0.25f);
					else
						jumpMultiplier = Mathf.Min(
							4f, jumpMultiplier + 0.25f);
				}

				if (UnityEngine.Input.GetKeyDown(KeyCode.LeftArrow))
				{
					if (subSelected == 0)
						speedMultiplier = Mathf.Max(
							1f, speedMultiplier - 0.25f);
					else
						jumpMultiplier = Mathf.Max(
							1f, jumpMultiplier - 0.25f);
				}
			}
		}
		else
		{
			if (UnityEngine.Input.GetKeyDown(KeyCode.UpArrow))
				selected = (selected - 1 + categories.Length)
					% categories.Length;

			if (UnityEngine.Input.GetKeyDown(KeyCode.DownArrow))
				selected = (selected + 1) % categories.Length;

			if (UnityEngine.Input.GetKeyDown(KeyCode.Return))
			{
				subSelected = 0;
				subMenuOpen = true;
			}
		}
	}

	private void ToggleSelectedMod()
	{
		if (selected == 4)
		{
			switch (subSelected)
			{
				case 0:
					RefreshItemCatalog();
					catalogTitle = "Spawn Items";
					showingCatalog = true;
					subSelected = 0;
					return;

				case 1:
					RefreshMonsterCatalog();
					catalogTitle = "Spawn Monsters";
					showingCatalog = true;
					subSelected = 0;
					return;

				case 2:
					healthEnabled = !healthEnabled;
					Logger.LogInfo("Infinite Health: " + healthEnabled);
					return;

				case 3:
					DestroyAllMonsters();
					return;

				case 4:
					SetMaxMoneyOffline();
					return;
			}
		}

		if (selected == 3 && subSelected == 0)
		{
			BuildRpcBrowser();
			showingRpcBrowser = true;
			subSelected = 0;
			return;
		}

		if (selected == 2)
		{
			if (subSelected == 0)
				monsterESP = !monsterESP;
			else if (subSelected == 1)
				itemESP = !itemESP;
			else if (subSelected == 2)
				playerESP = !playerESP;

			Logger.LogInfo(mods[selected][subSelected] + " toggled.");
			return;
		}

		if (selected == 0)
		{
			switch (subSelected)
			{
				case 0:
					speedEnabled = !speedEnabled;
					break;

				case 1:
					jumpEnabled = !jumpEnabled;
					if (jumpEnabled)
						FindJumpField();
					break;

				case 2:
					staminaEnabled = !staminaEnabled;
					break;

				case 3:
					flyEnabled = !flyEnabled;
					if (flyEnabled)
					{
						upDownEnabled = false;
						carEnabled = false;
					}
					break;

				case 4:
					upDownEnabled = !upDownEnabled;
					if (upDownEnabled)
					{
						flyEnabled = false;
						carEnabled = false;
					}
					break;

				case 5:
					carEnabled = !carEnabled;
					if (carEnabled)
					{
						flyEnabled = false;
						upDownEnabled = false;
					}
					break;
			}

			Logger.LogInfo(mods[selected][subSelected] + " toggled.");
			return;
		}

		Logger.LogInfo(
			mods[selected][subSelected] + " is not implemented."
		);
	}

	private void ApplyMods()
	{
		PlayerController player = PlayerController.instance;

		if (player == null)
		{
			if (cachedPlayer != null)
				RestorePlayerStats();

			cachedPlayer = null;
			jumpFieldInitialized = false;
			return;
		}

		if (cachedPlayer != player)
		{
			RestorePlayerStats();

			cachedPlayer = player;
			originalMoveSpeed = player.MoveSpeed;
			originalSprintSpeed = player.SprintSpeed;
			originalCrouchSpeed = player.CrouchSpeed;
			originalEnergyDrain = player.EnergySprintDrain;

			jumpField = null;
			jumpFieldInitialized = false;
		}

		player.MoveSpeed = speedEnabled
			? originalMoveSpeed * speedMultiplier
			: originalMoveSpeed;

		player.SprintSpeed = speedEnabled
			? originalSprintSpeed * speedMultiplier
			: originalSprintSpeed;

		player.CrouchSpeed = speedEnabled
			? originalCrouchSpeed * speedMultiplier
			: originalCrouchSpeed;

		player.EnergySprintDrain = staminaEnabled
			? 0f
			: originalEnergyDrain;

		if (staminaEnabled)
			player.EnergyCurrent = player.EnergyStart;

		if (jumpEnabled)
		{
			if (!jumpFieldInitialized)
				FindJumpField();

			if (jumpField != null)
			{
				try
				{
					jumpField.SetValue(
						player, originalJumpValue * jumpMultiplier);
				}
				catch (Exception ex)
				{
					Logger.LogWarning(
						"Jump multiplier failed: " + ex.Message);
					jumpField = null;
				}
			}
		}
		else if (jumpField != null)
		{
			try
			{
				jumpField.SetValue(player, originalJumpValue);
			}
			catch { }
		}
	}

	private void ApplyExtraMovement()
	{
		PlayerController player = PlayerController.instance;
		if (player == null)
			return;

		Transform target = player.transform;
		Transform cam = Camera.main != null
			? Camera.main.transform
			: target;

		if (flyEnabled)
		{
			Vector3 direction = Vector3.zero;

			if (UnityEngine.Input.GetKey(KeyCode.W))
				direction += cam.forward;
			if (UnityEngine.Input.GetKey(KeyCode.S))
				direction -= cam.forward;
			if (UnityEngine.Input.GetKey(KeyCode.D))
				direction += cam.right;
			if (UnityEngine.Input.GetKey(KeyCode.A))
				direction -= cam.right;
			if (UnityEngine.Input.GetKey(KeyCode.Space))
				direction += Vector3.up;
			if (UnityEngine.Input.GetKey(KeyCode.LeftControl))
				direction -= Vector3.up;

			target.position += direction.normalized
				* 8f * Time.unscaledDeltaTime;
		}

		if (upDownEnabled)
		{
			float vertical = 0f;

			if (UnityEngine.Input.GetKey(KeyCode.Space))
				vertical += 1f;
			if (UnityEngine.Input.GetKey(KeyCode.LeftControl))
				vertical -= 1f;

			target.position += Vector3.up
				* vertical * 5f * Time.unscaledDeltaTime;
		}

		if (carEnabled)
		{
			float forward = 0f;

			if (UnityEngine.Input.GetKey(KeyCode.W))
				forward += 1f;
			if (UnityEngine.Input.GetKey(KeyCode.S))
				forward -= 1f;

			Vector3 flatForward = target.forward;
			flatForward.y = 0f;
			flatForward.Normalize();

			target.position += flatForward
				* forward * 10f * Time.unscaledDeltaTime;
		}
	}

	private void FindJumpField()
	{
		PlayerController player = PlayerController.instance;
		if (player == null)
			return;

		jumpFieldInitialized = true;

		foreach (FieldInfo field in player.GetType().GetFields(
			BindingFlags.Instance |
			BindingFlags.Public |
			BindingFlags.NonPublic))
		{
			string name = field.Name.ToLowerInvariant();

			bool looksLikeJump = name.Contains("jump") &&
				(name.Contains("force") ||
				 name.Contains("height") ||
				 name.Contains("power"));

			if (!looksLikeJump || field.FieldType != typeof(float))
				continue;

			try
			{
				float value = (float)field.GetValue(player);
				if (value <= 0f)
					continue;

				originalJumpValue = value;
				jumpField = field;
				Logger.LogInfo("Jump field found: " + field.Name);
				return;
			}
			catch { }
		}

		if (!jumpWarningLogged)
		{
			jumpWarningLogged = true;
			Logger.LogWarning("No compatible jump-force field was found.");
		}
	}

	private void ApplyHealth()
	{
		if (!healthEnabled)
			return;

		try
		{
			PlayerAvatar avatar = PlayerAvatar.instance;

			if (avatar == null || avatar.playerHealth == null)
				return;

			object health = avatar.playerHealth;

			if (cachedHealth != health)
			{
				cachedHealth = health;
				godModeField = health.GetType().GetField(
					"godMode",
					BindingFlags.Instance |
					BindingFlags.NonPublic |
					BindingFlags.Public
				);
			}

			if (godModeField != null &&
				godModeField.FieldType == typeof(bool))
			{
				godModeField.SetValue(health, true);
			}
		}
		catch (Exception ex)
		{
			Logger.LogWarning("Infinite Health failed: " + ex.Message);
		}
	}

	private void SetMaxMoneyOffline()
	{
		try
		{
			Type semiFunc = FindType("SemiFunc");
			MethodInfo multiplayerMethod =
				FindStaticMethod(semiFunc, "IsMultiplayer", 0);

			if (multiplayerMethod == null ||
				multiplayerMethod.ReturnType != typeof(bool))
			{
				Logger.LogWarning(
					"Max Money cancelled: multiplayer state unavailable.");
				return;
			}

			bool multiplayer =
				(bool)multiplayerMethod.Invoke(null, null);

			if (multiplayer)
			{
				Logger.LogWarning(
					"Max Money is restricted to single-player.");
				return;
			}

			if (StatsManager.instance == null ||
				StatsManager.instance.runStats == null)
			{
				Logger.LogWarning("StatsManager runStats is unavailable.");
				return;
			}

			StatsManager.instance.runStats["currency"] = 999999;

			Logger.LogInfo(
				"Set single-player run currency to 999999.");
		}
		catch (Exception ex)
		{
			Logger.LogWarning("Max Money failed: " + ex.Message);
		}
	}

	private void RefreshItemCatalog()
	{
		itemCatalog.Clear();

		try
		{
			if (StatsManager.instance == null ||
				StatsManager.instance.itemDictionary == null)
				return;

			foreach (object item in
				StatsManager.instance.itemDictionary.Values)
			{
				if (item != null && !itemCatalog.Contains(item))
					itemCatalog.Add(item);
			}

			itemCatalog.Sort((a, b) =>
				string.Compare(
					GetObjectName(a),
					GetObjectName(b),
					StringComparison.OrdinalIgnoreCase));
		}
		catch (Exception ex)
		{
			Logger.LogWarning(
				"Could not read item catalog: " + ex.Message);
		}
	}

	private void RefreshMonsterCatalog()
	{
		monsterCatalog.Clear();

		try
		{
			Type setupType = FindType("EnemySetup");

			if (setupType == null)
			{
				Logger.LogWarning("EnemySetup type was not found.");
				return;
			}

			foreach (UnityEngine.Object obj in
				Resources.FindObjectsOfTypeAll(setupType))
			{
				if (obj != null && !monsterCatalog.Contains(obj))
					monsterCatalog.Add(obj);
			}

			monsterCatalog.Sort((a, b) =>
				string.Compare(
					GetObjectName(a),
					GetObjectName(b),
					StringComparison.OrdinalIgnoreCase));
		}
		catch (Exception ex)
		{
			Logger.LogWarning(
				"Could not read monster catalog: " + ex.Message);
		}
	}

	private List<object> CurrentCatalog()
	{
		return catalogTitle == "Spawn Monsters"
			? monsterCatalog
			: itemCatalog;
	}

	private void SpawnCatalogEntry(int index)
	{
		List<object> catalog = CurrentCatalog();

		if (index < 0 || index >= catalog.Count)
			return;

		if (catalogTitle == "Spawn Monsters")
			SpawnMonster(catalog[index]);
		else
			SpawnItem(catalog[index]);
	}

	private void SpawnItem(object item)
	{
		try
		{
			PlayerAvatar avatar = PlayerAvatar.instance;

			if (avatar == null)
			{
				Logger.LogWarning("Player avatar is unavailable.");
				return;
			}

			Vector3 position = avatar.transform.position
				+ Vector3.up
				+ avatar.transform.forward * 1.5f;

			object prefabRef = GetMember(item, "prefab");
			GameObject prefab = GetMember(prefabRef, "Prefab")
				as GameObject;

			if (prefab == null)
			{
				Logger.LogWarning(
					"No prefab found for " + GetObjectName(item));
				return;
			}

			if (IsMultiplayer())
			{
				MethodInfo method = FindStaticMethod(
					FindType("Items"), "SpawnItem", 3);

				if (method == null)
				{
					Logger.LogWarning("Items.SpawnItem was not found.");
					return;
				}

				method.Invoke(null, new object[]
				{
					item, position, Quaternion.identity
				});
			}
			else
			{
				UnityEngine.Object.Instantiate(
					prefab, position, Quaternion.identity);
			}

			Logger.LogInfo("Spawned item: " + GetObjectName(item));
		}
		catch (Exception ex)
		{
			Logger.LogWarning("Item spawn failed: " + ex.Message);
		}
	}

	private void SpawnMonster(object setup)
	{
		try
		{
			PlayerAvatar avatar = PlayerAvatar.instance;

			if (avatar == null)
			{
				Logger.LogWarning("Player avatar is unavailable.");
				return;
			}

			Vector3 position = avatar.transform.position
				+ avatar.transform.forward * 3f;

			if (IsMultiplayer())
			{
				MethodInfo method = FindStaticMethod(
					FindType("Enemies"), "SpawnEnemy", 4);

				if (method == null)
				{
					Logger.LogWarning("Enemies.SpawnEnemy was not found.");
					return;
				}

				method.Invoke(null, new object[]
				{
					setup, position, Quaternion.identity, false
				});
			}
			else
			{
				object spawnObjects = GetMember(setup, "spawnObjects");
				IEnumerable enumerable = spawnObjects as IEnumerable;

				if (enumerable == null)
				{
					Logger.LogWarning("Enemy has no spawnObjects list.");
					return;
				}

				object first = null;

				foreach (object value in enumerable)
				{
					first = value;
					break;
				}

				object prefabRef = GetMember(first, "Prefab");
				GameObject prefab = prefabRef as GameObject;

				if (prefab == null)
				{
					Logger.LogWarning("Enemy prefab was not found.");
					return;
				}

				UnityEngine.Object.Instantiate(
					prefab, position, Quaternion.identity);
			}

			Logger.LogInfo(
				"Requested monster spawn: " + GetObjectName(setup));
		}
		catch (Exception ex)
		{
			Logger.LogWarning("Monster spawn failed: " + ex.Message);
		}
	}

	private void DestroyAllMonsters()
	{
		try
		{
			Type healthType = FindType("EnemyHealth");

			if (healthType == null)
			{
				Logger.LogWarning("EnemyHealth type was not found.");
				return;
			}

			UnityEngine.Object[] objects =
				Resources.FindObjectsOfTypeAll(healthType);

			int disabled = 0;

			foreach (UnityEngine.Object obj in objects)
			{
				Component component = obj as Component;

				if (component == null ||
					!component.gameObject.scene.IsValid())
					continue;

				Transform root = component.transform;

				for (int i = 0; i < 5 && root.parent != null; i++)
					root = root.parent;

				if (root != null && root.gameObject.scene.IsValid())
				{
					root.gameObject.SetActive(false);
					disabled++;
				}
			}

			Logger.LogInfo("Disabled monster roots: " + disabled);
		}
		catch (Exception ex)
		{
			Logger.LogWarning(
				"Destroy All Monsters failed: " + ex.Message);
		}
	}

	private bool IsMultiplayer()
	{
		try
		{
			Type type = FindType("SemiFunc");
			MethodInfo method = FindStaticMethod(type, "IsMultiplayer", 0);

			if (method == null || method.ReturnType != typeof(bool))
				return true;

			return (bool)method.Invoke(null, null);
		}
		catch
		{
			return true;
		}
	}

	private void BuildRpcBrowser()
	{
		rpcCatalog.Clear();

		try
		{
			foreach (Assembly assembly in
				AppDomain.CurrentDomain.GetAssemblies())
			{
				Type[] types;

				try
				{
					types = assembly.GetTypes();
				}
				catch (ReflectionTypeLoadException ex)
				{
					types = ex.Types.Where(t => t != null).ToArray();
				}
				catch
				{
					continue;
				}

				foreach (Type type in types)
				{
					MethodInfo[] methods;

					try
					{
						methods = type.GetMethods(
							BindingFlags.Instance |
							BindingFlags.Static |
							BindingFlags.Public |
							BindingFlags.NonPublic);
					}
					catch
					{
						continue;
					}

					foreach (MethodInfo method in methods)
					{
						bool isRpc = method.GetCustomAttributes(false)
							.Any(attribute =>
								attribute.GetType().Name == "PunRPC");

						if (!isRpc)
							continue;

						string parameters = string.Join(
							", ",
							method.GetParameters()
								.Select(p => p.ParameterType.Name)
								.ToArray());

						rpcCatalog.Add(
							type.Name + "." + method.Name
							+ "(" + parameters + ")");
					}
				}
			}

			rpcCatalog.Sort(StringComparer.OrdinalIgnoreCase);

			if (rpcCatalog.Count == 0)
				rpcCatalog.Add("No RPC methods found.");
		}
		catch (Exception ex)
		{
			rpcCatalog.Add("RPC scan failed: " + ex.Message);
		}
	}

	private Type FindType(string typeName)
	{
		foreach (Assembly assembly in
			AppDomain.CurrentDomain.GetAssemblies())
		{
			try
			{
				Type type = assembly.GetTypes()
					.FirstOrDefault(t => t.Name == typeName);

				if (type != null)
					return type;
			}
			catch (ReflectionTypeLoadException ex)
			{
				Type type = ex.Types.FirstOrDefault(
					t => t != null && t.Name == typeName);

				if (type != null)
					return type;
			}
			catch { }
		}

		return null;
	}

	private MethodInfo FindStaticMethod(
		Type type, string name, int parameterCount)
	{
		if (type == null)
			return null;

		return type.GetMethods(
				BindingFlags.Public |
				BindingFlags.NonPublic |
				BindingFlags.Static)
			.FirstOrDefault(m =>
				m.Name == name &&
				m.GetParameters().Length == parameterCount);
	}

	private object GetMember(object instance, string name)
	{
		if (instance == null)
			return null;

		Type type = instance.GetType();

		FieldInfo field = type.GetField(
			name,
			BindingFlags.Instance |
			BindingFlags.Public |
			BindingFlags.NonPublic);

		if (field != null)
			return field.GetValue(instance);

		PropertyInfo property = type.GetProperty(
			name,
			BindingFlags.Instance |
			BindingFlags.Public |
			BindingFlags.NonPublic);

		return property != null
			? property.GetValue(instance, null)
			: null;
	}

	private string GetObjectName(object obj)
	{
		if (obj == null)
			return "Unknown";

		UnityEngine.Object unityObject = obj as UnityEngine.Object;

		if (unityObject != null)
			return unityObject.name.Replace("Item ", "");

		return obj.ToString();
	}

	private void RestorePlayerStats()
	{
		if (cachedPlayer == null)
			return;

		cachedPlayer.MoveSpeed = originalMoveSpeed;
		cachedPlayer.SprintSpeed = originalSprintSpeed;
		cachedPlayer.CrouchSpeed = originalCrouchSpeed;
		cachedPlayer.EnergySprintDrain = originalEnergyDrain;

		if (jumpField != null)
		{
			try
			{
				jumpField.SetValue(cachedPlayer, originalJumpValue);
			}
			catch { }
		}
	}

	private void OnDestroy()
	{
		RestorePlayerStats();

		if (harmony != null)
			harmony.UnpatchSelf();

		if (Instance == this)
			Instance = null;
	}

	private void OnGUI()
	{
		if (!menuOpen && animation <= 0f)
			return;

		InitializeStyles();

		float eased = 1f - Mathf.Pow(1f - animation, 3f);
		float x = 25f;
		float y = 25f + (1f - eased) * 25f;
		float mainWidth = 350f;
		float mainHeight = 350f;

		GUI.color = new Color(1f, 1f, 1f, eased);

		GUI.Box(new Rect(x, y, mainWidth, mainHeight), GUIContent.none);

		GUI.Label(
			new Rect(x + 20f, y + 16f, mainWidth - 40f, 42f),
			"XMODS GUI",
			titleStyle);

		for (int i = 0; i < categories.Length; i++)
		{
			categoryStyle.normal.textColor =
				i == selected && !subMenuOpen ? pink : white;

			GUI.Label(
				new Rect(x + 22f, y + 72f + i * 40f,
					mainWidth - 44f, 34f),
				(i == selected && !subMenuOpen ? ">  " : "   ")
					+ categories[i],
				categoryStyle);
		}

		GUI.Label(
			new Rect(x + 20f, y + mainHeight - 40f,
				mainWidth - 40f, 25f),
			"F4: Toggle Menu",
			footerStyle);

		if (subMenuOpen)
			DrawSubMenu(x + mainWidth + 12f, y);

		if (showingCatalog)
			DrawCatalog(x + mainWidth + 12f, y);

		if (showingRpcBrowser)
			DrawRpcBrowser(x + mainWidth + 12f, y);

		if (monsterESP || itemESP || playerESP)
			DrawESP();

		GUI.color = Color.white;
	}

	private void InitializeStyles()
	{
		if (titleStyle != null)
			return;

		titleStyle = new GUIStyle(GUI.skin.label)
		{
			fontSize = 30,
			fontStyle = FontStyle.Bold
		};
		titleStyle.normal.textColor = pink;

		categoryStyle = new GUIStyle(GUI.skin.label)
		{
			fontSize = 19
		};
		categoryStyle.normal.textColor = white;

		footerStyle = new GUIStyle(GUI.skin.label)
		{
			fontSize = 14
		};
		footerStyle.normal.textColor = pink;

		hintStyle = new GUIStyle(GUI.skin.label)
		{
			fontSize = 14
		};
		hintStyle.normal.textColor = mutedWhite;
	}

	private void DrawSubMenu(float x, float y)
	{
		string[] entries = mods[selected];
		float height = 100f + entries.Length * 38f;

		GUI.Box(new Rect(x, y, 340f, height), GUIContent.none);

		GUI.Label(
			new Rect(x + 18f, y + 16f, 300f, 36f),
			categories[selected],
			titleStyle);

		for (int i = 0; i < entries.Length; i++)
		{
			categoryStyle.normal.textColor =
				i == subSelected ? pink : white;

			GUI.Label(
				new Rect(x + 20f, y + 62f + i * 38f, 310f, 32f),
				(i == subSelected ? ">  " : "   ")
					+ entries[i] + GetStatus(selected, i),
				categoryStyle);
		}

		if (selected == 0 && subSelected == 0)
		{
			GUI.Label(
				new Rect(x + 20f, y + height - 48f, 310f, 22f),
				"Speed: " + speedMultiplier.ToString("0.00")
					+ "x  (LEFT/RIGHT)",
				hintStyle);
		}
		else if (selected == 0 && subSelected == 1)
		{
			GUI.Label(
				new Rect(x + 20f, y + height - 48f, 310f, 22f),
				"Jump: " + jumpMultiplier.ToString("0.00")
					+ "x  (LEFT/RIGHT)",
				hintStyle);
		}

		GUI.Label(
			new Rect(x + 18f, y + height - 26f, 310f, 22f),
			"ENTER: Select  BACKSPACE: Back",
			footerStyle);
	}

	private string GetStatus(int category, int index)
	{
		if (category == 0)
		{
			switch (index)
			{
				case 0: return speedEnabled ? " [ON]" : " [OFF]";
				case 1: return jumpEnabled ? " [ON]" : " [OFF]";
				case 2: return staminaEnabled ? " [ON]" : " [OFF]";
				case 3: return flyEnabled ? " [ON]" : " [OFF]";
				case 4: return upDownEnabled ? " [ON]" : " [OFF]";
				case 5: return carEnabled ? " [ON]" : " [OFF]";
			}
		}

		if (category == 2)
		{
			if (index == 0) return monsterESP ? " [ON]" : " [OFF]";
			if (index == 1) return itemESP ? " [ON]" : " [OFF]";
			if (index == 2) return playerESP ? " [ON]" : " [OFF]";
		}

		if (category == 4 && index == 2)
			return healthEnabled ? " [ON]" : " [OFF]";

		return "";
	}

	private void DrawCatalog(float x, float y)
	{
		List<object> catalog = CurrentCatalog();
		float height = 420f;

		GUI.Box(new Rect(x, y, 390f, height), GUIContent.none);

		GUI.Label(
			new Rect(x + 18f, y + 14f, 350f, 38f),
			catalogTitle + " (" + catalog.Count + ")",
			titleStyle);

		int visibleRows = 8;
		int start = Mathf.Clamp(
			subSelected - visibleRows / 2,
			0,
			Mathf.Max(0, catalog.Count - visibleRows));

		for (int row = 0; row < visibleRows; row++)
		{
			int index = start + row;
			if (index >= catalog.Count)
				break;

			categoryStyle.normal.textColor =
				index == subSelected ? pink : white;

			GUI.Label(
				new Rect(x + 20f, y + 62f + row * 35f, 350f, 30f),
				(index == subSelected ? ">  " : "   ")
					+ GetObjectName(catalog[index]),
				categoryStyle);
		}

		GUI.Label(
			new Rect(x + 18f, y + height - 28f, 350f, 22f),
			"ENTER: Spawn  BACKSPACE: Back",
			footerStyle);
	}

	private void DrawRpcBrowser(float x, float y)
	{
		float height = 420f;

		GUI.Box(new Rect(x, y, 460f, height), GUIContent.none);

		GUI.Label(
			new Rect(x + 18f, y + 14f, 420f, 38f),
			"RPC Browser (Read Only)",
			titleStyle);

		int rows = 10;
		int start = Mathf.Clamp(
			subSelected - rows / 2,
			0,
			Mathf.Max(0, rpcCatalog.Count - rows));

		for (int i = 0; i < rows; i++)
		{
			int index = start + i;
			if (index >= rpcCatalog.Count)
				break;

			GUI.Label(
				new Rect(x + 18f, y + 58f + i * 30f, 425f, 26f),
				rpcCatalog[index],
				hintStyle);
		}

		GUI.Label(
			new Rect(x + 18f, y + height - 28f, 430f, 22f),
			"Inspection only. BACKSPACE: Back",
			footerStyle);
	}

	private void DrawESP()
	{
		Camera cam = Camera.main;
		if (cam == null)
			return;

		if (Time.unscaledTime >= nextESPRefresh)
		{
			nextESPRefresh = Time.unscaledTime + ESPRefreshInterval;

			if (monsterESP)
				RefreshESPList(espMonsters, monsterIds, "EnemyHealth");

			if (itemESP)
				RefreshESPList(espItems, itemIds, "ValuableObject");

			if (playerESP)
				RefreshESPList(espPlayers, playerIds, "PlayerAvatar");
		}

		if (monsterESP)
			DrawObjectLabels(
				cam, espMonsters, "MONSTER",
				new Color(1f, 0.3f, 0.3f));

		if (itemESP)
			DrawObjectLabels(
				cam, espItems, "ITEM",
				new Color(1f, 0.85f, 0.2f));

		if (playerESP)
			DrawObjectLabels(
				cam, espPlayers, "PLAYER",
				new Color(0.3f, 1f, 0.5f));
	}

	private void RefreshESPList(
		List<GameObject> objects,
		HashSet<int> ids,
		string typeName)
	{
		objects.Clear();
		ids.Clear();

		Type type = FindType(typeName);
		if (type == null)
			return;

		foreach (UnityEngine.Object obj in
			Resources.FindObjectsOfTypeAll(type))
		{
			Component component = obj as Component;
			if (component == null)
				continue;

			GameObject target = component.gameObject;

			if (!target.scene.IsValid() ||
				!target.activeInHierarchy)
				continue;

			if (ids.Add(target.GetInstanceID()))
				objects.Add(target);
		}
	}

	private void DrawObjectLabels(
		Camera cam,
		List<GameObject> objects,
		string label,
		Color color)
	{
		foreach (GameObject obj in objects)
		{
			if (obj == null || !obj.activeInHierarchy)
				continue;

			Vector3 screen = cam.WorldToScreenPoint(
				obj.transform.position);

			if (screen.z <= 0f)
				continue;

			GUI.color = color;

			GUI.Label(
				new Rect(
					screen.x - 80f,
					Screen.height - screen.y - 12f,
					240f,
					24f),
				label + ": " + obj.name);
		}

		GUI.color = Color.white;
	}
}

[HarmonyPatch(typeof(PlayerController), "Update")]
public static class InfiniteStaminaPatch
{
	[HarmonyPostfix]
	private static void Postfix(PlayerController __instance)
	{
		if (XMODSGUITemplate.Instance == null ||
			!XMODSGUITemplate.Instance.InfiniteStaminaEnabled)
			return;

		if (__instance != PlayerController.instance)
			return;

		__instance.EnergySprintDrain = 0f;
		__instance.EnergyCurrent = __instance.EnergyStart;
	}
}